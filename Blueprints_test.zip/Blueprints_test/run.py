from application import app
app.run(debug=True,port=5004)
