from flask import Blueprint
from flask import Flask, logging
from flask_ask import Ask, statement, question, session, request
import json
import requests
from flask_ask import session
mod = Blueprint('amazon',__name__,)
ask = Ask(mod,"/newamazon")
@mod.route('/')
def home():
    return "amazon route "

@ask.launch
def start_skill():
    print(session)
    status=False
    if 'accessToken' in session['user']:
        status=True

    if(status==True):
        return statement("welcome! How i can help")
    else:
        return statement('Please link your account in the Alexa app') \
        .link_account_card()
