from flask import Blueprint
from flask import Flask
from flask_assistant import Assistant, tell,ask
import logging
logging.getLogger('flask_assistant').setLevel(logging.DEBUG)
mod = Blueprint('google',__name__)
assist = Assistant(mod, project_id='---google app id---')

@mod.route("/fun")
def home():
    return "google inside"


@assist.action('greeting')
def greet_and_start():
    speech = "Hey! Are you male or female?"
    return ask(speech)

@assist.action('Demo')
def hello_world():
    speech = 'Microphone check 1, 2 what is this?'
    return tell(speech)



