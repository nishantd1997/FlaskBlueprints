from flask import Flask

from application import amazon
from application import google
app = Flask(__name__)

from application.amazon.route import mod
from application.google.route import mod

app.register_blueprint(amazon.route.mod)
app.register_blueprint(google.route.mod,url_prefix="/google")
